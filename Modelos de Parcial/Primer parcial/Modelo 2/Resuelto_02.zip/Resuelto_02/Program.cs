﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Resuelto_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Ejercicios e = new Ejercicios();

            Console.WriteLine("Presione enter para salir...");
            Console.ReadLine();
        }
    }
}
